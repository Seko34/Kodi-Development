# -*- coding: iso-8859-1 -*-
""" crypto.keyedHash

    The keyedHash package.

    Copyright � (c) 2002 by Paul A. Lambert
    Read LICENSE.txt for license information.
"""
