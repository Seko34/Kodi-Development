# -*- coding: utf-8 -*-
#---------------------------------------------------------------------
'''
    Created on 11 aug. 2015
    
    @author: Seko
    @summary: Scraper Library
'''
#---------------------------------------------------------------------

# ____________________        I M P O R T        ____________________
import xbmcaddon

# ____________________     V A R I A B L E S     ____________________
settings = xbmcaddon.Addon(id='script.module.seko.scraper')
language = settings.getLocalizedString
version = "0.0.5"
plugin = "SekoScraper-" + version

